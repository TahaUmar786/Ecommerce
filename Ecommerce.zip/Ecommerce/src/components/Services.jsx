import React from 'react'
import { Link, Outlet } from 'react-router-dom'

const Services = () => {
  return (
    <div>
     <div className='container'>
     <Link to="shirt" className='me-3'>shirt</Link>
      <Link to="jeans">Jeans</Link>
     </div>
     <Outlet/>
    </div>
  )
}

export default Services
