import React from 'react'

const Jeans = () => {
  return (
    <div className='container'>
 <video className="js-video" muted playsInline preload="none" autoPlay loop controls width='900px'>
  <source type="video/mp4" src="https://cdn.shopify.com/videos/c/o/v/6ea99039075649928c5afd24328e4d6a.mp4" />
</video>
<div className='row'>
<div className='col-lg-3'>
<iframe width="200" height="150" src="https://www.youtube.com/embed/e5_LZ9gcfSM?si=xp-Fpx9x7IBSapLz" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen className=''></iframe>
</div>
<div className='col-lg-3'>
<iframe width="200" height="150" src="https://www.youtube.com/embed/e5_LZ9gcfSM?si=xp-Fpx9x7IBSapLz" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
</div>
<div className='col-lg-3'>
<iframe width="200" height="150" src="https://www.youtube.com/embed/e5_LZ9gcfSM?si=xp-Fpx9x7IBSapLz" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
</div>
<div className='col-lg-3'>
<iframe width="200" height="150" src="https://www.youtube.com/embed/e5_LZ9gcfSM?si=xp-Fpx9x7IBSapLz" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
</div>
</div>

<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1699.204879459331!2d74.5003756888975!3d31.59523007817294!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3919121d44507e99%3A0xf690c2ca87e0bcf3!2sJallo%20More%20Bata%20Pur%2C%20Lahore%2C%20Punjab%2C%20Pakistan!5e0!3m2!1sen!2s!4v1702973920048!5m2!1sen!2s" width={600} height={450} style={{border: 0}} allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade" />

</div>
  )
}

export default Jeans
