import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Navbar from './components/Navbar'
import { Route, Routes } from 'react-router-dom'
import Home from './components/Home'
import About from './components/About'
import Services from './components/Services'
import Shirts from './components/Shirts'
import Jeans from './components/Jeans'

function App() {
  const [count, setCount] = useState(0)

  return (
    <div className='container'>
  
<Navbar/>
<Routes>
  <Route path='/' element={<Home/>}></Route>
  <Route path='/about' element={<About/>}></Route>
  <Route path='/services' element={<Services/>}>

  <Route path='shirt' element={<Shirts/>}></Route>
  <Route path='jeans' element={<Jeans/>}></Route>

  </Route>
</Routes>
    </div>
  )
}

export default App
